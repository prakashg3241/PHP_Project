<?php
include("configdb.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include("header1.php");
         $current_logged_user_id=$_SESSION['id'];
         $inser="select * from book where user_id=$current_logged_user_id";
          $result=mysqli_query($connect,$inser);
          $row = mysqli_fetch_assoc($result);
          $movieName=$row['name'];
         $insert="select * from movies where description like '$movieName'";
          $result1=mysqli_query($connect,$insert);
         $rows = mysqli_fetch_assoc($result1);
         
?>
<div class="custom-product">
     <div class="col-sm-10">
        <div class="trending-wrapper">
            <h3>Orders</h3>
             <br> <br>
           
            <div class=" row searched-item cart-list-devider">
               
             <div class="col-sm-3">
                
               <img  src="<?php echo $rows["name"];?>"  alt="Image not found" height="250px" width="300px">
                      </div>
             <div class="col-sm-5">
                    <div class="">
                      <h2><?php echo $row["name"];?></h2>
                      <h5>Theatre name :<?php echo $row["theatre_name"];?></h5>
                      <h5>Date :<?php echo $row["date"];?></h5>
                      <h5>Time slot starts at :<?php echo $row["time"];?></h5>
                      <h5>No Of Seats :<?php echo $row["tickects"];?></h5>
                    </div>
             </div>
             <div class="col-sm-3">
                <a href="/removecart/{{$item->cart_id}}" class="btn btn-warning" >Cancel now</a>
             </div>
            </div>
            
          </div>
          

     </div>
</div>   
</body>
</html>

